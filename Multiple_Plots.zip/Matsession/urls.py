from django.conf.urls import include, url

from .views import displayimage1, displayimage2, displayimage3

urlpatterns = [
    url(r'^1/$', displayimage1),
    url(r'^2/$', displayimage2),
    url(r'^3/$', displayimage3),
]
