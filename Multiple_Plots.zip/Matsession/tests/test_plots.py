import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.gridspec as gridspec
from matplotlib.testing.decorators import image_comparison

@image_comparison(baseline_images=['Multiple_Plots_Figure1'],extensions=['png'])
def test_generate_figure1():

    # Write your functionality below


@image_comparison(baseline_images=['Multiple_Plots_Figure2'],extensions=['png'])
def test_generate_figure2():

    # Write your functionality below


@image_comparison(baseline_images=['Multiple_Plots_Figure3'],extensions=['png'])
def test_generate_figure3():

    # Write your functionality below
    
